// import logo from './logo.svg';
import './App.css';
import { data } from './data.js';
import Div1 from './Div1.js';
import './Div1.css';
import Img from './img.js';
import pic2 from './m1.jpg';
import pic1 from './m2.jpg';
import pic3 from './m3.jpg';
import pic4 from './m4.jpg';
import pic5 from './m5.jpg';
import pic6 from './c1.jpg';
import pic7 from './c2.jpg';
import pic8 from './c3.jpg';
import pic9 from './c4.jpg';
import pic10 from './c5.jpg';
import pic11 from './l1.jpg';
import pic12 from './l2.jpg';
import pic13 from './l3.jpg';
import pic14 from './l4.jpg';
import pic15 from './l6.jpg';
import pic16 from './l7.jpg';
import pic17 from './a1.jpg';

import pic18 from './a2.jpg';
import pic20 from './A4.jpg';

import pic19 from './a3.jpg';

import { categ } from './categ.js';
import Div3 from './Div3.js';
import lImg from './larImg.js';
import './larImg.css';
import Div2 from './Div2.js';
import './Div2.css';
import './Div1.css';
import Button from './Button.js';
import './button.css';
// import comp from './comp.js';
// import './comp.css';


function App() {

  return (
    <div className="App">

      
      <h1 style={{fontFamily:"Franklin Gothic Medium"}}>MOBCOMP ZONE</h1>
      <h2>Deals in all kinds of computers, laptops and mobiles with accessories</h2>

      <div id="but">

        <Button textToShow="Popular Products " />
        <Button textToShow="Recently Sold Products" />
        <Button textToShow="Category Details" />
        <Button textToShow="Picture Gallery" />
        <Button textToShow="User Reviews" />

      </div>

      <div className='mob'  style={{height:"630px"}}>
        <h2> Product: Mobiles</h2>  
        <Div1 imgurll={data[0].imgurll} id={data[0].id} company={data[0].company} modal={data[0].modal} price={data[0].price} specification={data[0].specification} guarantee={data[0].guarantee} color={data[0].color} />&nbsp;
        <Div1 imgurll={data[1].imgurll}  id={data[1].id} company={data[1].company} modal={data[1].modal} price={data[1].price} specification={data[1].specification} guarantee={data[1].guarantee} color={data[1].color} /> &nbsp;
        <Div1  imgurll={data[2].imgurll} id={data[2].id} company={data[2].company} modal={data[2].modal} price={data[2].price} specification={data[2].specification} guarantee={data[2].guarantee} color={data[2].color} /> &nbsp;
        <Div1 imgurll={data[3].imgurll}  id={data[3].id} company={data[3].company} modal={data[3].modal} price={data[3].price} specification={data[3].specification} guarantee={data[2].guarantee} color={data[3].color} /> &nbsp;

        <br></br>
        </div>
      
      <br></br>
      <div className="mob" style={{height:"630px"}}>
        <h2>Product: Computer</h2>
        <Div1  imgurll={data[4].imgurll} id={data[4].id} company={data[4].company} modal={data[4].modal} price={data[4].price} specification={data[4].specification} guarantee={data[4].guarantee} /> &nbsp;
        <Div1 imgurll={data[5].imgurll} id={data[5].id} company={data[5].company} modal={data[5].modal} price={data[5].price} specification={data[5].specification} guarantee={data[5].guarantee} /> &nbsp;
        <Div1 imgurll={data[6].imgurll} id={data[6].id} company={data[6].company} modal={data[6].modal} price={data[6].price} specification={data[6].specification} guarantee={data[6].guarantee} /> &nbsp;
        <Div1 imgurll={data[7].imgurll} id={data[7].id} company={data[7].company} modal={data[7].modal} price={data[7].price} specification={data[7].specification} guarantee={data[7].guarantee} />&nbsp;

        <br></br>
      </div>

      <div className="mob" style={{height:"630px"}}>
        <h2>Product: Laptop</h2>
        <Div1 imgurll={data[8].imgurll}  id={data[8].id} company={data[8].company} modal={data[8].modal} price={data[8].price} specification={data[8].specification} guarantee={data[8].guarantee} /> &nbsp;
        <Div1  imgurll={data[9].imgurll} id={data[9].id} company={data[9].company} modal={data[9].modal} price={data[9].price} specification={data[9].specification} guarantee={data[9].guarantee} /> &nbsp;
        <Div1  imgurll={data[10].imgurll} id={data[10].id} company={data[10].company} modal={data[10].modal} price={data[10].price} specification={data[10].specification} guarantee={data[10].guarantee} /> &nbsp;
        <Div1  imgurll={data[11].imgurll} id={data[11].id} company={data[11].company} modal={data[11].modal} price={data[11].price} specification={data[11].specification} guarantee={data[11].guarantee} />&nbsp;

        <br></br>
      </div>
      <br></br>
      <br></br>

      <div className='acce'>
        <h2>MOBILE ACCESSORIES</h2>

        <table border="2px" cellSpacing={0}  >
          <span>HANDSFREE</span>

          <tr>
            <tr rowspan="3">&nbsp;&nbsp;&nbsp;&nbsp;Company</tr>
            <th >Samsumg</th>
            <th>Faster</th>
            <th>Tecnix</th>

          </tr>
          <tr>
            <tr rowspan="3">&nbsp;&nbsp;&nbsp;&nbsp;Modal No</tr>
            <td>Samsumg-SA181</td>
            <td>Faster-FS12</td>
            <td>Technix-TC122</td>

          </tr>
          <tr>
            <tr rowspan="3">&nbsp;&nbsp;&nbsp;&nbsp;Price</tr>
            <td>Rs 220</td>
            <td>Rs 280</td>
            <td>Rs 320</td>

          </tr>

          <tr>
            <tr rowspan="3">&nbsp;&nbsp;&nbsp;&nbsp;Warranty</tr>
            <td>3 months</td>
            <td>1 month</td>
            <td>5 months</td>
          </tr>

        </table>

        <table border="2px" >
          <span>CHARGER</span>

          <tr>
            <tr rowspan="3">&nbsp;&nbsp;&nbsp;&nbsp;Company</tr>
            <th >Samsumg</th>
            <th>Faster</th>
            <th>Tecnix</th>

          </tr>
          <tr>
            <tr rowspan="3">&nbsp;&nbsp;&nbsp;&nbsp;Modal No</tr>
            <td>Samsumg-CHS1</td>
            <td> Faster-FS22</td>
            <td>Technix-TC222</td>

          </tr>
          <tr>
            <tr rowspan="3">&nbsp;&nbsp;&nbsp;&nbsp;Price</tr>
            <td>Rs 420</td>
            <td>Rs 580</td>
            <td>Rs 620</td>

          </tr>

          <tr>
            <tr rowspan="3">&nbsp;&nbsp;&nbsp;&nbsp;Warranty</tr>
            <td>2 months</td>
            <td>3 months</td>
            <td>5 months</td>
          </tr>

        </table>

        <table border="2px" id='cov'>
          <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;COVERS</span>
          
          <tr>
            <th colSpan={4}>Nokia</th>
            <th colSpan={3}>Q-MOBILE</th>

            <th colSpan={2} >INFINIX</th>

          </tr>

          <tr rowspan="3">
            <th>Modal</th>
            <td>NK-11</td>
            <td>NK-22</td>
            <td>NK-33</td>

            <td>QM-10</td>
            <td>QM-11</td>
            <td>QM-12</td>

            <td>IN-A00</td>
            <td>IN-A10</td>






          </tr>
          <tr rowspan="3">
            <th>Price</th>
            <td>Rs 500</td>
            <td>Rs 600</td>
            <td>Rs 800</td>

            <td>Rs 500</td>
            <td>Rs 200</td>
            <td>Rs 300</td>

            <td>Rs 120</td>
            <td>Rs 200</td>



          </tr>





        </table>


      </div>
      <div className="popprods">
       
        <table id="pop" cellspacing="5px" cellpadding="4px" border="2px">
        <h4>POPULAR PRODUCTS</h4>
          <tr>
            <th>Model No</th>
            <th>Product</th>
            <th>Sold</th>
            <th>Review Rating</th>
          </tr>
          <tr>

            <td>Nokia Lumia AFf-10</td>
            <td>Mobile</td>
            <td>10 pieces per day</td>
            <td>3 stars</td>
          </tr>

          <tr>

            <td>Qmobile A10</td>
            <td>Mobile</td>
            <td>12 pieces per day</td>
            <td>4 stars</td>
          </tr>

          <tr>

            <td>Lenovo LN-100</td>
            <td>Laptop</td>
            <td>10 pieces per day</td>
            <td>5 stars</td>
          </tr>

          <tr>

            <td>Techno TC-A902s</td>
            <td>Laptop</td>
            <td>15 pieces per day</td>
            <td>5 stars</td>
          </tr>

          <tr>

            <td>DELL DL-109</td>
            <td>Computer</td>
            <td>10 pieces per day</td>
            <td>5 stars</td>
          </tr>

          <tr>

            <td>Faster FS-12</td>
            <td>Handsfree</td>
            <td>20 pieces per day</td>
            <td>5 stars</td>
          </tr>

          <tr>

            <td>QM-11</td>
            <td>Cover</td>
            <td>12 pieces per day</td>
            <td>4 stars</td>
          </tr>
          <tr>

            <td>Technix TC-222</td>
            <td>Charger</td>
            <td>10 pieces per day</td>
            <td>5 stars</td>
          </tr>
        </table>
        <table id="recsoltab" border={"3px"} cellpadding="5px" cellspacing="5px">
          <h4 >Recently sold products</h4>
          <tr>
        <th >Product</th>
          <th >Model No</th>
          <th >Date</th>
          </tr>

          <tr>
            <td>Nokia</td>
            <td>A-0019</td>
            <td>9th July,2022</td>
          </tr>
          <tr>
            <td>Qmobile</td>
            <td>QM1-0019</td>
            <td>10th July,2022</td>
          </tr>
          <tr>
            <td>HP Laptop</td>
            <td>HP-0019</td>
            <td>11th July,2022</td>
          </tr>
          <tr>
            <td>Nokia</td>
            <td>A-SM019</td>
            <td>11th July,2022</td>
          </tr>
          <tr>
            <td>Lenovo Computer</td>
            <td>COMP-001</td>
            <td>12th July,2022</td>
          </tr>
          <tr>
            <td>Techno</td>
            <td>A-0019</td>
            <td>13th July,2022</td>
          </tr>


        </table>
      </div>
      <br></br>
      <br></br>

      <div id="mpic">
        <h2>PICTURE GALLERY</h2>
        <h4>AVAILABLE MOBILES</h4>
      <Img alt="error" src={pic2} height={240} width={260} />
      &nbsp;
      <Img alt="error" src={pic1} height={240} width={260} />
      <Img alt="error" src={pic3} height={240} width={260} />
      <Img alt="error" src={pic4} height={240} width={260} />
      <Img alt="error" src={pic5} height={240} width={260} />

    <br></br>
    <h4>AVAILABLE COMPUTERS</h4>
    <Img alt="error" src={pic6} height={240} width={260}  />
      &nbsp;
      <Img alt="error" src={pic7} height={240} width={260} />
      <Img alt="error" src={pic8} height={240} width={260} />
      <Img alt="error" src={pic9} height={240} width={260} />
      <Img alt="error" src={pic10} height={240} width={260} />
      <br></br>

      <h4>AVAILABLE LAPTOPS</h4>
      <Img alt="error" src={pic16} height={240} width={260} />
      &nbsp;
      <Img alt="error" src={pic13} height={240} width={260} />
      <Img alt="error" src={pic14} height={240} width={260} />
      <Img alt="error" src={pic15} height={240} width={260} />
      <Img alt="error" src={pic12} height={240} width={260} />


      </div>
      <br></br>
      <div id="category"  style={{height:"440px"}}>
        <h2>CATEGORIES AND DETAILS</h2>
      <Div3 name={categ[0].name} category={categ[0].category} priceRangeN={categ[0].priceRangeN} priceRangeQ={categ[0].priceRangeQ} priceRangeI={categ[0].priceRangeI} UserRatings={categ[0].UserRatings} />&nbsp;
      <Div3 name={categ[1].name} category={categ[1].category} priceRangeN={categ[1].priceRangeN} priceRangeQ={categ[1].priceRangeQ} priceRangeI={categ[1].priceRangeI} UserRatings={categ[1].UserRatings} />&nbsp;
      <Div3 name={categ[2].name} category={categ[2].category} priceRangeN={categ[2].priceRangeN} priceRangeQ={categ[2].priceRangeQ} priceRangeI={categ[2].priceRangeI} UserRatings={categ[2].UserRatings} />&nbsp;
</div>
      <div id="ur">
        <h2>USER REVIEWS</h2>
         <div className='uuu' style={{display:"flex"}}>
         <div className='sd'>
        <Img alt="error" src={pic18} height={240} width={260} />
        <p style={{fontStyle:"italic",color:"grey",fontWeight:"bold",padding:"4px"}}>I have bought a lenovo computer and it is so good and all the features are very nice.</p>
        </div>
      
       <div className='sd'>
        <Img alt="error" src={pic17} height={240} width={260} />
       <p style={{fontStyle:"italic",color:"grey",fontWeight:"bold",padding:"4px"}}>{"I have bought a HP laptop and it is so good and all the features are very nice."}</p>
        </div>
        <div className='sd'>
        <Img alt="error" src={pic19} height={240} width={260} />
        <p style={{fontStyle:"italic",color:"grey",fontWeight:"bold",padding:"4px"}}>I have bought a Qmobile mobile and it is so good and all the features are very nice.</p>
        </div> 

        <div className='sd'>
        <Img alt="error" src={pic20} height={240} width={260} />
        <p style={{fontStyle:"italic",color:"grey",fontWeight:"bold",padding:"4px"}}>I have bought a Dell Laptop and it is so good and all the features are very nice.</p>
        </div> 


         </div>
        

        

   

      </div>






    </div>
  );
}

export default App;
