import React from "react";
import './Div1.css';
const Div1=({imgurll,id,company,modal,price,specification,guarantee,color})=>{
    return(
        <div className="Divs">
            <img src={imgurll} height={10}></img>
            <h1>{id}</h1>
            <h2>{company}</h2>
            <h3>{modal}</h3>
            <h3>{price}</h3>
            <h3>{specification}</h3>
            <h3>{guarantee}</h3>
            <h3>{color}</h3>
        </div>
    );
}
export default Div1;