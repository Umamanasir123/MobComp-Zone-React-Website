import React from "react";
import './Div2.css';
const Div2=({id,company,modal,price,guarantee,color})=>{
    return(
        <div className="div2">
         
            <h1>{id}</h1>
            <h2>{company}</h2>
            <h3>{modal}</h3>
            <h3>{price}</h3>
            <h3>{guarantee}</h3>
            <h3>{color}</h3>
        </div>
    );
}
export default Div2;