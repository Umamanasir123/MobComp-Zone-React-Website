
export const categ=[
    {
        name:"PRODUCT: Mobiles",
        category:"CATEGORY: Nokia, Qmobile, Infinix",
        priceRangeN:"PRICE RANGE: Nokia:30,000-6,000",
        priceRangeQ:"PRICE RANGE: Qmobile:20,000-50,000",
        priceRangeI:"PRICE RANGE: Infinix:30,000-70,000",
        UserRatings: "USER RATINGS: Infinix(1st) Nokia(2nd) QMobile(3rd)"
    },
    {
        name:"PRODUCT: Computers",
        category:"CATEGORY: DELL, HP, Lenovo",
        priceRangeN:"PRICE RANGE: DELL:80,000-170,000",
        priceRangeQ:"PRICE RANGE: HP:120,000-190,000",
        priceRangeI:"PRICE RANGE: Lenovo:130,000-200,000",
        UserRatings: "USER RATINGS: HP(1st) DELL(2nd) Lenovo(3rd)"
    },
    {
        name:"PRODUCT: Laptops",
        category:"CATEGORY: Techno, DELL, Samsung",
        priceRangeN:"PRICE RANGE: Techno:100,000-170,000",
        priceRangeQ:"PRICE RANGE: DELL:140,000-200,000",
        priceRangeI:"PRICE RANGE: Samsung:120,000-230,000",
        UserRatings: "USER RATINGS: DELL(1st) Samsung(2nd) Techno(3rd)"
    }
]