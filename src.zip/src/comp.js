import React from "react";
import './comp.css';
const comp=({alt,src,para})=>{
    return(
        <div className="comp">
            <img alt={alt} src={src} />
            <p>{para}</p>
        </div>

    );

}
export default comp;