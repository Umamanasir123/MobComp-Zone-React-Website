import React from "react";
import './Div3.css';
const Div3=({name,category,priceRangeN,priceRangeQ,priceRangeI,UserRatings})=>{
    return(
        <div className="Divthree">
         
            <h2 style={{color:"black"}}>{name}</h2>
            <h3>{category}</h3>
            <h3>{priceRangeN}</h3>
            <h3>{priceRangeQ}</h3>
            <h3>{priceRangeI}</h3>
            <h3>{UserRatings}</h3>
            
   </div>
    );
}
export default Div3;