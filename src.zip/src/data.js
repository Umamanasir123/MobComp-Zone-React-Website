export const data=[
    {
        imgurll:"https://img.freepik.com/free-photo/phone-screen-with-abstract-marble-aesthetic_53876-145553.jpg",
        id:"MOB-001",
        company:"Company: Nokia ",
        modal:"Modal: Nokia Lumia A-10",
        price:"Price: 40,000",
        specification:"Specification: 12GB RAM 6GB ROM 3 cameras ", 
        guarantee:"Warranty: 1 year",
        color:"Colors: blue, red, margenda"
    },
    {
        imgurll:"https://images.unsplash.com/photo-1567581935884-3349723552ca?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8bW9iaWxlfGVufDB8fDB8fHww&w=1000&q=80",
        id:"MOB-002",      
        company:"Company: Nokia ",
        modal:"Modal: Nokia Lumia AFf-10",
        price:"Price: 30,000",
        specification:"Specification: 16GB RAM 8GB ROM 2 cameras ", 
        guarantee:"Warranty: 1.5 year",
        color:"Colors: black, purple, margenda"
    },
    {
        imgurll:"https://img.freepik.com/premium-psd/mobile-phone-mockup-with-editable-design-changeable-colors_196070-196.jpg",
        id:"MOB-003",
        company:"Company: Q-Mobile ",
        modal:"Modal: Q-PLAY A-10",
        price:"Price: 45,000",
        specification:"Specification: 18GB RAM 6GB ROM 2 cameras ", 
        guarantee:"Warranty: 6 months",
        color:"Colors: gray, purple, margenda"
    },

    {
        imgurll:"https://images.unsplash.com/photo-1621330396167-b3d451b9b83b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8c21hcnRwaG9uZXN8ZW58MHx8MHx8fDA%3D&w=1000&q=80",
        id:"MOB-004",
        company:"Company: Infinix ",
        modal:"Modal: HOT 10 Play",
        price:"Price: 50,000",
        specification:"Specification: 18GB RAM 8GB ROM 3 cameras ", 
        guarantee:"Warranty: 3 year",
        color:"Colors: gray, purple, blue"
    },

    {
        imgurll:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSVgboubt3kpcPsILDkbajLwGwrtLNXImjSIv460KYNiF4O8rOOSWlDs2QUqGyAB906aQs&usqp=CAU",
        id:"COMP-001",
        company:"Company:DELL ",
        modal:"Modal: DEL-123OAS",
        price:"Price: 150,000",
        specification:"Specification: 18GB RAM 8GB ROM 64 bit Processor ", 
        guarantee:"Warranty: 3 year"
        
    },
    {
        imgurll:"https://5.imimg.com/data5/WX/TK/MY-2395610/hp-smart-laptops-500x500.jpg",
        id:"COMP-002",
        company:"Company:HP ",
        modal:"Modal: HPASH-9281",
        price:"Price: 130,000",
        specification:"Specification: 28GB RAM 8GB ROM 32 bit Processor ", 
        guarantee:"Warranty: 1.5 year"
        
        
    },{
        imgurll:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSj0lBiIrlRtEaz1yEYwA-TQXSGd4M1o-nDsUGMCc6UnkNDgFufwqUZl4aJ6K7AjgH-Sic&usqp=CAU",
        id:"COMP-003",
        company:"Company:Lenovo ",
        modal:"Modal: LN-123OAS",
        price:"Price: 150,000",
        specification:"Specification: 18GB RAM 8GB ROM 68 bit Processor ", 
        guarantee:"Warranty: 2 year"
        
    },
    {
        imgurll:"https://5.imimg.com/data5/SELLER/Default/2022/12/FN/ZL/OJ/3866941/desktop-computer-250x250.jpg",
        id:"COMP-004",
        company:"Company:Lenovo ",
        modal:"Modal: LN-009OyS",
        price:"Price: 180,000",
        specification:"Specification: 28GB RAM 16GB ROM 72 bit Processor ", 
        guarantee:"Warranty: 2.5 year"
        
    },
    {
        imgurll:"https://5.imimg.com/data5/GF/YP/MY-4959135/lenovo-laptop-500x500-500x500.png",
        id:"LAP-001",
        company:"Company:Lenovo ",
        modal:"Modal: LN-LP00A1",
        price:"Price: 180,000",
        specification:"Specification: 16GB RAM 16GB ROM 32 bit Processor ", 
        guarantee:"Warranty: 1.2 year"
        
    }
    ,
    {
        imgurll:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR51_TptDEnkVRL5V_kTVMvictpNcfq1HXX-_N9he728xkVJO3SVjwgdv0cbKCZsqZeBYI&usqp=CAU",
        id:"LAP-002",
        company:"Company:Dell ",
        modal:"Modal: LDL-009OS",
        price:"Price: 190,000",
        specification:"Specification: 28GB RAM 16GB ROM 72 bit Processor ", 
        guarantee:"Warranty: 2 year"
        
    },
    {
        imgurll:"https://media.istockphoto.com/id/1023428598/photo/3d-illustration-laptop-isolated-on-white-background-laptop-with-empty-space-screen-laptop-at.webp?b=1&s=170667a&w=0&k=20&c=sy1ZPHTrpawA2sGhzsU5_PY7rxJI4TRLgQzsYoI2MGc=",
        id:"LAP-003",
        company:"Company:Techno ",
        modal:"Modal: TH-A9OTS",
        price:"Price: 120,000",
        specification:"Specification: 28GB RAM 16GB ROM 72 bit Processor ", 
        guarantee:"Warranty: 2.5 year"
        
    },
    {
        imgurll:"https://image1280.macovi.de/images/product_images/1280/811286_1__8444478-1.jpg",
        id:"LAP-004",
        company:"Company: Samsung",
        modal:"Modal: SAM-0NaS",
        price:"Price: 130,000",
        specification:"Specification: 28GB RAM 16GB ROM 64 bit Processor ", 
        guarantee:"Warranty: 1 year"
        
    }
]