import React from "react";
import './button.css';

const Button=({textToShow})=>{
    return(
        <button>
            <i>{textToShow}</i>
        </button>
    );
}
export default Button;