import React from "react";
import './img.css';

const Img =({alt,src})=>{
    return(
        <img alt={alt} src={src} />
     ) ;
}
export default Img