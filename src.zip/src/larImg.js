import React from "react";
import './larImg.css';

const lImg =({alt,src})=>{
    return(
        <img alt={alt} src={src} />
     ) ;
}
export default lImg;